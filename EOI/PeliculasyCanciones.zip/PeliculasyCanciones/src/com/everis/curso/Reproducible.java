package com.everis.curso;

public interface Reproducible {

		void play();
		void stop();
}
