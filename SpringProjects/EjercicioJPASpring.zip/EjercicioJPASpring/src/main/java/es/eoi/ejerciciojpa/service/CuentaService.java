package es.eoi.ejerciciojpa.service;

import java.util.List;

import es.eoi.ejerciciojpa.entities.Banco;
import es.eoi.ejerciciojpa.entities.Cliente;
import es.eoi.ejerciciojpa.entities.Cuenta;

public interface CuentaService {

	List<Cuenta> MostrarCuenta();

	boolean InsertarCuenta(Cuenta cuenta);

	Cuenta buscarCuenta(int id);

	boolean updateCuenta(int id, Cliente cliente, Banco banco, int salario);

	boolean removeCuenta(int id);

}