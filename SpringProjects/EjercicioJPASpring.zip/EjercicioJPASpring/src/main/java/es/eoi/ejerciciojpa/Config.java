package es.eoi.ejerciciojpa;

public class Config {

}
